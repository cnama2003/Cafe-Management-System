<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cafena</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        body{
            background:url('logincofee.jpg');
            background-size:cover;
            background-repeat:no-repeat;
        }
        .img{
            position:absolute;
            top:0px;
            left:50.2%;
        }
        a{color:white;}
    button{
        position: absolute;
    top: 18px;
    right: 2.2%;
    color: white;
    background-color: #0069d9;
    border: none;

        }
    </style>
</head>
<body>
    <div class="img">
        <img src="logo-black.png"style="color:white;" alt="">
    </div>
    <div class="btn">
        <button><a href="login.php">Login</a></button>
    </div>
    
</body>
</html>